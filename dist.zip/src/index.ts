import { AppDataSource } from "./data.source"
import express from 'express'
import 'reflect-metadata'
import * as dotenv from 'dotenv';
dotenv.config();

async function start() {
    try{
        await AppDataSource.initialize();
        const app = express();
        app.use(express.json());

        const port = process.env.PORT ?? 8080;
        app.listen(port,()=>console.log(`App listening on  +http://localhost:${port}`)
        )
    }catch(err){
        console.log("Cannot connect to db");
        process.exit(1);
    }
}
start()