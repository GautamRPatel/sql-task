import * as jwt from "jsonwebtoken"
export default interface jwtPayload extends jwt.jwtPayload{
    sub:string;//id
    email:string;
}