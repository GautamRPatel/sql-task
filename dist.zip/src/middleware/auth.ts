import { NextFunction ,Response,Request} from "express";
import * as jwt from "jsonwebtoken"
import jwtPayload from "../types/jwtPayload";
import { AppDataSource } from "../data.source";
import { User } from "../entity/User";

export async function verifyToken(req:Request,res:Response,next:NextFunction){
    const JWT_SECRET = process.env.JWT_SECRET as string;
    const authHeader = req.headers["authorization"];

    if(!authHeader?.startsWith('Bearer ')){
        res.status(401).json({error:"Missing token"});
        return;
    }

    const token = authHeader.slice(7);

    try{
        const decoded = jwt.verify(token,JWT_SECRET) as jwtPayload;
        const user = await AppDataSource.getRepository(User).createQueryBuilder('user')
                                                            .where("user.id = :id",{id:Number(decoded.sub)})
                                                            .getOne()
        if(!user){
            return res.status(401).json({message:"User not found"})
        }
        req.user = user;
        next();
    }
    catch(err){
        return res.status(401).json({message:"Invalid or expired token"})
    }
}