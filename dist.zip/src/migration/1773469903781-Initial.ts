import { MigrationInterface, QueryRunner } from "typeorm";

export class Initial1773469903781 implements MigrationInterface {
    name = 'Initial1773469903781'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "user" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "username" varchar(30) NOT NULL, "email" varchar NOT NULL, "passwordHash" varchar NOT NULL, CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e22" UNIQUE ("email"))`);
        await queryRunner.query(`CREATE TABLE "organiser" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "eventId" integer, "userId" integer, CONSTRAINT "REL_efcbafe08acb1de5c77155ddae" UNIQUE ("userId"))`);
        await queryRunner.query(`CREATE TABLE "events" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar(100) NOT NULL, "description" text NOT NULL, "venue" varchar NOT NULL, "city" varchar(100) NOT NULL, "start_date" datetime NOT NULL, "end_date" datetime NOT NULL, "status" varchar NOT NULL, "organiseId" integer)`);
        await queryRunner.query(`CREATE TABLE "tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "seats" integer NOT NULL, "eventsId" integer)`);
        await queryRunner.query(`CREATE TABLE "bookings" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "status" varchar NOT NULL, "userId" integer, "tierId" integer, CONSTRAINT "REL_c12601a518f15808ac0b88b927" UNIQUE ("tierId"))`);
        await queryRunner.query(`CREATE TABLE "temporary_organiser" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "eventId" integer, "userId" integer, CONSTRAINT "REL_efcbafe08acb1de5c77155ddae" UNIQUE ("userId"), CONSTRAINT "FK_0f136cfbd070124cd79801ba52d" FOREIGN KEY ("eventId") REFERENCES "events" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION, CONSTRAINT "FK_efcbafe08acb1de5c77155ddae1" FOREIGN KEY ("userId") REFERENCES "user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_organiser"("id", "eventId", "userId") SELECT "id", "eventId", "userId" FROM "organiser"`);
        await queryRunner.query(`DROP TABLE "organiser"`);
        await queryRunner.query(`ALTER TABLE "temporary_organiser" RENAME TO "organiser"`);
        await queryRunner.query(`CREATE TABLE "temporary_events" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar(100) NOT NULL, "description" text NOT NULL, "venue" varchar NOT NULL, "city" varchar(100) NOT NULL, "start_date" datetime NOT NULL, "end_date" datetime NOT NULL, "status" varchar NOT NULL, "organiseId" integer, CONSTRAINT "FK_0ea1bd682ad216a26c93ee5306c" FOREIGN KEY ("organiseId") REFERENCES "organiser" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_events"("id", "title", "description", "venue", "city", "start_date", "end_date", "status", "organiseId") SELECT "id", "title", "description", "venue", "city", "start_date", "end_date", "status", "organiseId" FROM "events"`);
        await queryRunner.query(`DROP TABLE "events"`);
        await queryRunner.query(`ALTER TABLE "temporary_events" RENAME TO "events"`);
        await queryRunner.query(`CREATE TABLE "temporary_tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "seats" integer NOT NULL, "eventsId" integer, CONSTRAINT "FK_6decea6ead8b01d51c1f9f53115" FOREIGN KEY ("eventsId") REFERENCES "events" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_tier"("id", "name", "seats", "eventsId") SELECT "id", "name", "seats", "eventsId" FROM "tier"`);
        await queryRunner.query(`DROP TABLE "tier"`);
        await queryRunner.query(`ALTER TABLE "temporary_tier" RENAME TO "tier"`);
        await queryRunner.query(`CREATE TABLE "temporary_bookings" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "status" varchar NOT NULL, "userId" integer, "tierId" integer, CONSTRAINT "REL_c12601a518f15808ac0b88b927" UNIQUE ("tierId"), CONSTRAINT "FK_38a69a58a323647f2e75eb994de" FOREIGN KEY ("userId") REFERENCES "user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION, CONSTRAINT "FK_c12601a518f15808ac0b88b9271" FOREIGN KEY ("tierId") REFERENCES "tier" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_bookings"("id", "status", "userId", "tierId") SELECT "id", "status", "userId", "tierId" FROM "bookings"`);
        await queryRunner.query(`DROP TABLE "bookings"`);
        await queryRunner.query(`ALTER TABLE "temporary_bookings" RENAME TO "bookings"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "bookings" RENAME TO "temporary_bookings"`);
        await queryRunner.query(`CREATE TABLE "bookings" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "status" varchar NOT NULL, "userId" integer, "tierId" integer, CONSTRAINT "REL_c12601a518f15808ac0b88b927" UNIQUE ("tierId"))`);
        await queryRunner.query(`INSERT INTO "bookings"("id", "status", "userId", "tierId") SELECT "id", "status", "userId", "tierId" FROM "temporary_bookings"`);
        await queryRunner.query(`DROP TABLE "temporary_bookings"`);
        await queryRunner.query(`ALTER TABLE "tier" RENAME TO "temporary_tier"`);
        await queryRunner.query(`CREATE TABLE "tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "seats" integer NOT NULL, "eventsId" integer)`);
        await queryRunner.query(`INSERT INTO "tier"("id", "name", "seats", "eventsId") SELECT "id", "name", "seats", "eventsId" FROM "temporary_tier"`);
        await queryRunner.query(`DROP TABLE "temporary_tier"`);
        await queryRunner.query(`ALTER TABLE "events" RENAME TO "temporary_events"`);
        await queryRunner.query(`CREATE TABLE "events" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar(100) NOT NULL, "description" text NOT NULL, "venue" varchar NOT NULL, "city" varchar(100) NOT NULL, "start_date" datetime NOT NULL, "end_date" datetime NOT NULL, "status" varchar NOT NULL, "organiseId" integer)`);
        await queryRunner.query(`INSERT INTO "events"("id", "title", "description", "venue", "city", "start_date", "end_date", "status", "organiseId") SELECT "id", "title", "description", "venue", "city", "start_date", "end_date", "status", "organiseId" FROM "temporary_events"`);
        await queryRunner.query(`DROP TABLE "temporary_events"`);
        await queryRunner.query(`ALTER TABLE "organiser" RENAME TO "temporary_organiser"`);
        await queryRunner.query(`CREATE TABLE "organiser" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "eventId" integer, "userId" integer, CONSTRAINT "REL_efcbafe08acb1de5c77155ddae" UNIQUE ("userId"))`);
        await queryRunner.query(`INSERT INTO "organiser"("id", "eventId", "userId") SELECT "id", "eventId", "userId" FROM "temporary_organiser"`);
        await queryRunner.query(`DROP TABLE "temporary_organiser"`);
        await queryRunner.query(`DROP TABLE "bookings"`);
        await queryRunner.query(`DROP TABLE "tier"`);
        await queryRunner.query(`DROP TABLE "events"`);
        await queryRunner.query(`DROP TABLE "organiser"`);
        await queryRunner.query(`DROP TABLE "user"`);
    }

}
