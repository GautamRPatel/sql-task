import { MigrationInterface, QueryRunner } from "typeorm";

export class PriceColumnTier1773470700549 implements MigrationInterface {
    name = 'PriceColumnTier1773470700549'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "temporary_tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "seats" integer NOT NULL, "eventsId" integer, "price" decimal(5,2) NOT NULL, CONSTRAINT "FK_6decea6ead8b01d51c1f9f53115" FOREIGN KEY ("eventsId") REFERENCES "events" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_tier"("id", "name", "seats", "eventsId") SELECT "id", "name", "seats", "eventsId" FROM "tier"`);
        await queryRunner.query(`DROP TABLE "tier"`);
        await queryRunner.query(`ALTER TABLE "temporary_tier" RENAME TO "tier"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "tier" RENAME TO "temporary_tier"`);
        await queryRunner.query(`CREATE TABLE "tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "seats" integer NOT NULL, "eventsId" integer, CONSTRAINT "FK_6decea6ead8b01d51c1f9f53115" FOREIGN KEY ("eventsId") REFERENCES "events" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "tier"("id", "name", "seats", "eventsId") SELECT "id", "name", "seats", "eventsId" FROM "temporary_tier"`);
        await queryRunner.query(`DROP TABLE "temporary_tier"`);
    }

}
