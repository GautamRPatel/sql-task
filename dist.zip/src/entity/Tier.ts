import { Column, Entity, ManyToMany, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { Events } from "./Events";

@Entity()
export class Tier{
    @PrimaryGeneratedColumn()
    id!:number

    @Column({type:"varchar"})
    name!:string

    @Column({type:"int",nullable:false})
    seats!:number

    @Column({nullable:false,type:"decimal",precision:5,scale:2})
    price!:number

    @ManyToOne(()=>Events,(events)=>events.eventsTier)
    events!:Events;
}