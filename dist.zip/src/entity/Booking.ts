import { Column, Entity, JoinColumn, ManyToOne, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { User } from "./User";
import { Tier } from "./Tier";

@Entity()
export class Bookings{
    @PrimaryGeneratedColumn()
    id!:number

    @Column({type:"varchar"})
    status!:string

    @ManyToOne(()=>User,(user)=>user.ticketBookings)
    user!:User;

    @OneToOne(()=>Tier)
    @JoinColumn()
    tier!:Tier
}

// add tier entity