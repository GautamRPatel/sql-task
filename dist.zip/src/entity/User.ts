import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm"
import { Events } from "./Events"
import { Bookings } from "./Booking"
import { Tier } from "./Tier"

@Entity()
export class User {

    @PrimaryGeneratedColumn()
    id!: number

    @Column({type:"varchar",length:30})
    username!: string

    @Column({unique:true})
    email!:string

    @Column({nullable:false})
    passwordHash!:string

    @OneToMany(()=>Bookings,(bookings)=>bookings.user)
    ticketBookings!:Bookings[];
}
