import { Entity,PrimaryGeneratedColumn,Column, ManyToOne, OneToMany } from "typeorm";
import { User } from "./User";
import { Tier } from "./Tier";
import { Organiser } from "./Organiser";

@Entity()
export class Events{
    @PrimaryGeneratedColumn()
    id!:number

    @Column({type:"varchar",length:100})
    title!:string
    
    @Column({type:"text"})
    description!:string

    @Column({type:"varchar"})
    venue!:string

    @Column({type:"varchar",length:100})
    city!:string

    @Column({type:"datetime"})
    start_date!:Date

    @Column({type:"datetime"})
    end_date!:Date

    @Column({type:"varchar"})
    status!:string

    @OneToMany(()=>Tier,(tier)=>tier.events)
    eventsTier!:Tier[]

    @ManyToOne(()=>Organiser,(organise)=>organise.organiseEvent)
    organise!:Organiser;

    @OneToMany(()=>Organiser,(organise)=>organise.event)
    multiEvents!:Organiser[]
}