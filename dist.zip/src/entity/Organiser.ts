import { Column, Entity, JoinColumn, ManyToMany, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { User } from "./User";
import { Events } from "./Events";

@Entity()
export class Organiser{
    @PrimaryGeneratedColumn()
    id!:number


    @OneToMany(()=>Events,(event)=>event.organise)
    organiseEvent!:Events[];


    @ManyToOne(()=>Events,(event)=>event.multiEvents)
    event!:Events;

    @OneToOne(()=>User)
    @JoinColumn()
    user!:User

    
}