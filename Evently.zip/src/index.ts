
import cookieParser from 'cookie-parser';
import * as dotenv from 'dotenv';
import express from 'express';
import 'reflect-metadata';
import { AppDataSource } from "./data.source";
import { globalErrorHandler } from "./middleware/errorMiddleware";
import authRouter from "./routes/authRoute";
import bookingRouter from './routes/bookingsRoute';
import eventTierRouter from './routes/eventTierRoute';
import reportRouter from './routes/reportsRoute';
dotenv.config();


async function start() {
    try{
        const app = express();
        app.use(express.json());
        app.use(express.urlencoded({extended:true}))
        const port = process.env.PORT || 8080;
        app.use(cookieParser())
        await AppDataSource.initialize();
        app.use("/api",authRouter);
        app.use("/event",eventTierRouter);
        app.use("/book",bookingRouter);
        app.use("/reports",reportRouter)
        app.use(globalErrorHandler)
        app.listen(port,()=>console.log(`App listening on http://localhost:${port}`)
        )
    }catch(err){
        console.log("Cannot connect to db");
        process.exit(1);
    }
}
start()