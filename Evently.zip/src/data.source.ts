import "reflect-metadata";
import { DataSource } from "typeorm";
import { Bookings } from "./entity/Bookings";
import { Events } from "./entity/Events";
import { Tier } from "./entity/Tier";
import { User } from "./entity/User";

export const AppDataSource = new DataSource({
    type:process.env.DB_TYPE as "better-sqlite3" || "better-sqlite3",
    database:process.env.DB_DATABASE ?? "database.db",
    synchronize:process.env.DB_SYNCHRONIZE === 'true',
    // synchronize:true,
    logging: process.env.DB_LOGGING === "true",
    entities: [User,Bookings,Tier,Events],
    migrations: ["src/migration/*.ts"],
})
