import { Router } from "express";
import { verifyToken } from "../middleware/authMiddleware";
import { getAverageTicketPriceByCity, getCancelledBookingsAndLostRevenue, getEventsWithLowSeats, getJanuaryRevenue, getMonthlyRevenueTrend2025, getPublishedEventsWithZeroBookings, getTierBreakdownEvent, getTop3BestSellingEvents, getTopCityQ1_2025, getTopRevenueTierType, getTopSpendingUser, getUniqueAttendeesByOrganiser, getUpcomingEventSeatUtilization } from "../controllers/reports";

const reportRouter = Router();

reportRouter.get("/getJanuaryRevenue",verifyToken,getJanuaryRevenue);
reportRouter.get("/getTopCityQ1_2025",verifyToken,getTopCityQ1_2025);
reportRouter.get("/getTop3BestSellingEvents",verifyToken,getTop3BestSellingEvents);
reportRouter.get("/getTierBreakdownEvent",verifyToken,getTierBreakdownEvent);
reportRouter.get("/getEventsWithLowSeats",verifyToken,getEventsWithLowSeats);
reportRouter.get("/getAverageTicketPriceByCity",verifyToken,getAverageTicketPriceByCity);
reportRouter.get("/getUniqueAttendeesByOrganiser/:id",verifyToken,getUniqueAttendeesByOrganiser);
reportRouter.get("/getCancelledBookingsAndLostRevenue",verifyToken,getCancelledBookingsAndLostRevenue);
reportRouter.get("/getTopRevenueTierType",verifyToken,getTopRevenueTierType);
reportRouter.get("/getPublishedEventsWithZeroBookings",verifyToken,getPublishedEventsWithZeroBookings);
reportRouter.get("/getMonthlyRevenueTrend2025",verifyToken,getMonthlyRevenueTrend2025);
reportRouter.get("/getTopSpendingUser",verifyToken,getTopSpendingUser);
reportRouter.get("/getUpcomingEventSeatUtilization",verifyToken,getUpcomingEventSeatUtilization);
export default reportRouter;