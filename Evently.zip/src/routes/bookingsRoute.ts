import { Router } from "express";
import { verifyToken } from "../middleware/authMiddleware";
import { bookTicket, cancelBooking } from "../controllers/bookings";
import { deflateRaw } from "node:zlib";

const bookingRouter = Router();

bookingRouter.post("/tier/:id",verifyToken,bookTicket);
bookingRouter.patch("/:id/cancel",verifyToken,cancelBooking);

export default bookingRouter;