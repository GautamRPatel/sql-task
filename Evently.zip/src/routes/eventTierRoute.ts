import { Router } from "express";
import { verifyToken } from "../middleware/authMiddleware";
import { addEvent, cancelEvent, editEvent, publishEvent } from "../controllers/event";
import { addTier, deleteTier, editTier } from "../controllers/tier";

const eventTierRouter = Router();

eventTierRouter.post("",verifyToken,addEvent);
eventTierRouter.put("/edit/:id",verifyToken,editEvent);
eventTierRouter.patch("/:id/cancel",verifyToken,cancelEvent);
eventTierRouter.patch("/:id/publish",verifyToken,publishEvent);
eventTierRouter.post("/:id/tier",verifyToken,addTier)
eventTierRouter.put("/tier/:id/edit",verifyToken,editTier)
eventTierRouter.delete("/tier/:id/remove",verifyToken,deleteTier)
export default eventTierRouter;