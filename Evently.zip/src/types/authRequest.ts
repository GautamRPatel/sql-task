import { Request } from "express";
interface User{
    id:number,
    email:string
}
export interface AuthRequest extends Request{
    user?:User
}