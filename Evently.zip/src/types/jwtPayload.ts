import * as jwt from "jsonwebtoken"
export default interface jwtPayload extends jwt.JwtPayload{
    sub:string;//id
    email:string;
}