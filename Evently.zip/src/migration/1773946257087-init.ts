import { MigrationInterface, QueryRunner } from "typeorm";

export class Init1773946257087 implements MigrationInterface {
    name = 'Init1773946257087'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "user" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "username" varchar(30) NOT NULL, "email" varchar NOT NULL, "passwordHash" varchar NOT NULL, "created_at" datetime NOT NULL DEFAULT (datetime('now')), CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e22" UNIQUE ("email"))`);
        await queryRunner.query(`CREATE TABLE "events" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar(100) NOT NULL, "description" text NOT NULL, "venue" varchar NOT NULL, "city" varchar NOT NULL, "start_date" datetime NOT NULL, "end_date" datetime NOT NULL, "status" varchar CHECK( "status" IN ('draft','published','cancelled') ) NOT NULL DEFAULT ('draft'), "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "organiserId" integer)`);
        await queryRunner.query(`CREATE TABLE "tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "capacity" integer NOT NULL, "price" decimal(10,2) NOT NULL, "eventsId" integer)`);
        await queryRunner.query(`CREATE TABLE "bookings" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "status" varchar CHECK( "status" IN ('booked','cancelled') ) NOT NULL DEFAULT ('booked'), "quantity" integer NOT NULL, "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "userId" integer, "tierId" integer)`);
        await queryRunner.query(`CREATE TABLE "temporary_events" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar(100) NOT NULL, "description" text NOT NULL, "venue" varchar NOT NULL, "city" varchar NOT NULL, "start_date" datetime NOT NULL, "end_date" datetime NOT NULL, "status" varchar CHECK( "status" IN ('draft','published','cancelled') ) NOT NULL DEFAULT ('draft'), "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "organiserId" integer, CONSTRAINT "FK_c7d2c5a6caba3caa041a263992c" FOREIGN KEY ("organiserId") REFERENCES "user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_events"("id", "title", "description", "venue", "city", "start_date", "end_date", "status", "createdAt", "organiserId") SELECT "id", "title", "description", "venue", "city", "start_date", "end_date", "status", "createdAt", "organiserId" FROM "events"`);
        await queryRunner.query(`DROP TABLE "events"`);
        await queryRunner.query(`ALTER TABLE "temporary_events" RENAME TO "events"`);
        await queryRunner.query(`CREATE TABLE "temporary_tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "capacity" integer NOT NULL, "price" decimal(10,2) NOT NULL, "eventsId" integer, CONSTRAINT "FK_6decea6ead8b01d51c1f9f53115" FOREIGN KEY ("eventsId") REFERENCES "events" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_tier"("id", "name", "capacity", "price", "eventsId") SELECT "id", "name", "capacity", "price", "eventsId" FROM "tier"`);
        await queryRunner.query(`DROP TABLE "tier"`);
        await queryRunner.query(`ALTER TABLE "temporary_tier" RENAME TO "tier"`);
        await queryRunner.query(`CREATE TABLE "temporary_bookings" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "status" varchar CHECK( "status" IN ('booked','cancelled') ) NOT NULL DEFAULT ('booked'), "quantity" integer NOT NULL, "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "userId" integer, "tierId" integer, CONSTRAINT "FK_38a69a58a323647f2e75eb994de" FOREIGN KEY ("userId") REFERENCES "user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION, CONSTRAINT "FK_c12601a518f15808ac0b88b9271" FOREIGN KEY ("tierId") REFERENCES "tier" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_bookings"("id", "status", "quantity", "createdAt", "userId", "tierId") SELECT "id", "status", "quantity", "createdAt", "userId", "tierId" FROM "bookings"`);
        await queryRunner.query(`DROP TABLE "bookings"`);
        await queryRunner.query(`ALTER TABLE "temporary_bookings" RENAME TO "bookings"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "bookings" RENAME TO "temporary_bookings"`);
        await queryRunner.query(`CREATE TABLE "bookings" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "status" varchar CHECK( "status" IN ('booked','cancelled') ) NOT NULL DEFAULT ('booked'), "quantity" integer NOT NULL, "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "userId" integer, "tierId" integer)`);
        await queryRunner.query(`INSERT INTO "bookings"("id", "status", "quantity", "createdAt", "userId", "tierId") SELECT "id", "status", "quantity", "createdAt", "userId", "tierId" FROM "temporary_bookings"`);
        await queryRunner.query(`DROP TABLE "temporary_bookings"`);
        await queryRunner.query(`ALTER TABLE "tier" RENAME TO "temporary_tier"`);
        await queryRunner.query(`CREATE TABLE "tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "capacity" integer NOT NULL, "price" decimal(10,2) NOT NULL, "eventsId" integer)`);
        await queryRunner.query(`INSERT INTO "tier"("id", "name", "capacity", "price", "eventsId") SELECT "id", "name", "capacity", "price", "eventsId" FROM "temporary_tier"`);
        await queryRunner.query(`DROP TABLE "temporary_tier"`);
        await queryRunner.query(`ALTER TABLE "events" RENAME TO "temporary_events"`);
        await queryRunner.query(`CREATE TABLE "events" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar(100) NOT NULL, "description" text NOT NULL, "venue" varchar NOT NULL, "city" varchar NOT NULL, "start_date" datetime NOT NULL, "end_date" datetime NOT NULL, "status" varchar CHECK( "status" IN ('draft','published','cancelled') ) NOT NULL DEFAULT ('draft'), "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "organiserId" integer)`);
        await queryRunner.query(`INSERT INTO "events"("id", "title", "description", "venue", "city", "start_date", "end_date", "status", "createdAt", "organiserId") SELECT "id", "title", "description", "venue", "city", "start_date", "end_date", "status", "createdAt", "organiserId" FROM "temporary_events"`);
        await queryRunner.query(`DROP TABLE "temporary_events"`);
        await queryRunner.query(`DROP TABLE "bookings"`);
        await queryRunner.query(`DROP TABLE "tier"`);
        await queryRunner.query(`DROP TABLE "events"`);
        await queryRunner.query(`DROP TABLE "user"`);
    }

}
