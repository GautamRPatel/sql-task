import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Tier } from "./Tier";
import { User } from "./User";
export enum EventStatus {
  DRAFT = "draft",
  PUBLISHED = "published",
  CANCELLED = "cancelled"
}
@Entity()
export class Events{
    @PrimaryGeneratedColumn()
    id!:number

    @Column({length:100})
    title!:string
    
    @Column({type:"text"})
    description!:string

    @Column()
    venue!:string

    @Column()
    city!:string

    @Column({type:"datetime"})
    start_date!:Date

    @Column({type:"datetime"})
    end_date!:Date

    @Column({type:"simple-enum",enum:EventStatus,default:EventStatus.DRAFT})
    status!:EventStatus

    @CreateDateColumn()
    createdAt!:Date;

    @ManyToOne(()=>User,(user)=>user.organisedEvents)
    organiser!:User

    @OneToMany(()=>Tier,(tier)=>tier.events)
    tiers!:Tier[]
}