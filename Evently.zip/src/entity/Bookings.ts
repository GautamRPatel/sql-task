import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { Tier } from "./Tier";
import { User } from "./User";
export enum BookingStatus {
  BOOKED = "booked",
  CANCELLED = "cancelled"
}
@Entity()
export class Bookings {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: "simple-enum",enum:BookingStatus,default:BookingStatus.BOOKED })
  status!: BookingStatus;

  @Column({ type: "int" })
  quantity!: number;

  @CreateDateColumn()
  createdAt!: Date;

  @ManyToOne(() => User, (user) => user.ticketBookings)
  user!: User;

  @ManyToOne(() => Tier, (tier) => tier.bookings)
  tier!: Tier;
}
