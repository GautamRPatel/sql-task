import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm"
import { Bookings } from "./Bookings"
import { Events } from "./Events"
@Entity()
export class User {

    @PrimaryGeneratedColumn()
    id!: number

    @Column({type:"varchar",length:30})
    username!: string

    @Column({unique:true})
    email!:string

    @Column({nullable:false})
    passwordHash!:string

    @CreateDateColumn()
    created_at!:Date;

    @OneToMany(()=> Events,(event)=>event.organiser)
    organisedEvents!:Event[];

    @OneToMany(()=>Bookings,(bookings)=>bookings.user)
    ticketBookings!:Bookings[];
}
