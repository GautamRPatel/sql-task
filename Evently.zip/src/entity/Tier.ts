import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Bookings } from "./Bookings";
import { Events } from "./Events";

@Entity()
export class Tier{
    @PrimaryGeneratedColumn()
    id!:number

    @Column()
    name!:string

    @Column({type:"int"})
    capacity!:number

    @Column({nullable:false,type:"decimal",precision:10,scale:2})
    price!:number

    @ManyToOne(()=>Events,(events)=>events.tiers)
    events!:Events;

    @OneToMany(()=>Bookings,(bookings)=>bookings.tier)
    bookings!:Bookings[]
}