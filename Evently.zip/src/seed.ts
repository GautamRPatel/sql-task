import "reflect-metadata";
import { AppDataSource } from "./data.source";
import { User } from "./entity/User";
import { Events, EventStatus } from "./entity/Events";
import { Tier } from "./entity/Tier";
import { BookingStatus,Bookings } from "./entity/Bookings";

function rand(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomDate(year: number, month: number) {
  return new Date(year, month, rand(1, 25));
}

async function seed() {
  await AppDataSource.initialize();

  const userRepo = AppDataSource.getRepository(User);
  const eventRepo = AppDataSource.getRepository(Events);
  const tierRepo = AppDataSource.getRepository(Tier);
  const bookingRepo = AppDataSource.getRepository(Bookings);

  await bookingRepo.clear();
  await tierRepo.clear();
  await eventRepo.clear();
  await userRepo.clear();

  console.log("🌱 Seeding reliable dataset...");

  // ================= USERS =================
  const organisers = await userRepo.save([
    { username: "rahul", email: "rahul@mail.com", passwordHash: "hash" },
    { username: "priya", email: "priya@mail.com", passwordHash: "hash" },
    { username: "vikas", email: "vikas@mail.com", passwordHash: "hash" },
  ]);

  const customers: User[] = [];
  for (let i = 1; i <= 30; i++) {
    customers.push(
      await userRepo.save({
        username: `customer${i}`,
        email: `customer${i}@mail.com`,
        passwordHash: "hash",
      })
    );
  }

  // ================= EVENTS =================
  const cities = ["Mumbai", "Delhi", "Bangalore", "Pune"];
  const events: Events[] = [];

  for (let month = 0; month < 12; month++) {
    const event = await eventRepo.save({
      title: `Event ${month + 1}`,
      description: "Professional conference",
      venue: `Venue ${month + 1}`,
      city: cities[rand(0, cities.length - 1)],
      start_date: randomDate(2025, month),
      end_date: randomDate(2025, month),
      status: EventStatus.PUBLISHED,
      organiser: { id: organisers[rand(0, 2)].id } as User,
    });

    events.push(event);
  }

  // Add future events (2026)
  for (let i = 0; i < 6; i++) {
    const event = await eventRepo.save({
      title: `Future Event ${i + 1}`,
      description: "Future conference",
      venue: `Future Venue ${i + 1}`,
      city: cities[rand(0, cities.length - 1)],
      start_date: randomDate(2026, rand(0, 11)),
      end_date: randomDate(2026, rand(0, 11)),
      status: EventStatus.PUBLISHED,
      organiser: { id: organisers[rand(0, 2)].id } as User,
    });

    events.push(event);
  }

  // Zero-booking event
  await eventRepo.save({
    title: "Zero Booking Event",
    description: "No one booked",
    venue: "Silent Hall",
    city: "Pune",
    start_date: new Date("2025-12-20"),
    end_date: new Date("2025-12-20"),
    status: EventStatus.PUBLISHED,
    organiser: { id: organisers[0].id } as User,
  });

  // ================= TIERS =================
  const tiers: Tier[] = [];

  for (const event of events) {
    const vip = await tierRepo.save({
      name: "VIP",
      price: rand(3000, 6000),
      capacity: 120,
      events: event,
    });

    const general = await tierRepo.save({
      name: "General Admission",
      price: rand(1000, 2500),
      capacity: 250,
      events: event,
    });

    tiers.push(vip, general);
  }

  // ================= BOOKINGS =================
  for (let i = 0; i < 200; i++) {
    const tier = tiers[rand(0, tiers.length - 1)];
    const quantity = rand(1, 5);

    if (tier.capacity < quantity) continue;

    const status =
      Math.random() > 0.15
        ? BookingStatus.BOOKED
        : BookingStatus.CANCELLED;

    await bookingRepo.save({
      quantity,
      status,
      user: customers[rand(0, customers.length - 1)],
      tier,
      createdAt: randomDate(2025, rand(0, 11)),
    });

    if (status === BookingStatus.BOOKED) {
      tier.capacity -= quantity;
      await tierRepo.save(tier);
    }
  }

  console.log("✅ Reliable dataset seeded successfully!");
  process.exit();
}

seed();