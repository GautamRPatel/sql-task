import * as bcrypt from "bcryptjs"


export async function hashPassword(pass:string){
    return bcrypt.hash(pass,12);
}

export async function comparePassword(userPass:string,passHash:string):Promise<boolean>{
    if(!userPass || !(await bcrypt.compare(userPass,passHash))){
        return false;
    }
    return true;
}