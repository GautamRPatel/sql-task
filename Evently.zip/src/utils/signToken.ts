import jwtPayload from "../types/jwtPayload";
import * as jwt from "jsonwebtoken"
export function signToken(payload:Omit<jwtPayload,"iat" | "exp">):string{
    return jwt.sign(payload,process.env.JWT_SECRET as string,{expiresIn:"1d"})
}
