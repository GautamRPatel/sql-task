import { NextFunction, Response } from "express";
import { AppDataSource } from "../data.source";
import { Events, EventStatus } from "../entity/Events";
import { User } from "../entity/User";
import {
  ForbiddenError,
  NotFoundError,
  ValidationError,
} from "../middleware/errorMiddleware";
import { AuthRequest } from "../types/authRequest";
import { Bookings, BookingStatus } from "../entity/Bookings";

export async function addEvent(
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) {
  try {
    const { title, description, venue, city, startDate, endDate, status } =
      req.body as {
        title: string;
        description: string;
        venue: string;
        city: string;
        startDate: Date;
        endDate: Date;
        status: EventStatus;
      };

    if (!title || !description || !venue || !city || !startDate || !endDate) {
      return next(new ValidationError("Missing required field"));
    }

    if (new Date(startDate) >= new Date(endDate)) {
      return next(new ValidationError("Start date must be before end date"));
    }

    const eventRepo = AppDataSource.getRepository(Events);

    const event = eventRepo.create({
      title,
      description,
      venue,
      city,
      start_date: new Date(startDate),
      end_date: new Date(endDate),
      status: EventStatus.DRAFT,
      organiser: { id: req.user?.id } as User,
    });

    await eventRepo.save(event);

    res.status(201).json({
      message: "Event created successfully",
      event: event,
    });
  } catch (err) {
    next(err);
  }
}

export async function editEvent(
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) {
  try {
    const eventRepo = AppDataSource.getRepository(Events);

    const event = await eventRepo
      .createQueryBuilder("event")
      .leftJoinAndSelect("event.organiser", "organiser")
      .where("event.id = :id", { id: Number(req.params.id) })
      .getOne();

    if (!event) {
      return next(new NotFoundError("Event"));
    }

    if (event.organiser.id !== req.user?.id) {
      return next(new ForbiddenError());
    }

    if (event.status === EventStatus.CANCELLED) {
      return next(new ValidationError("You cannot edit cancelled error"));
    }

    const { title, description, venue, city, startDate, endDate, status } =
      req.body as {
        title: string;
        description: string;
        venue: string;
        city: string;
        startDate: Date;
        endDate: Date;
        status: EventStatus;
      };

    if (title) event.title = title;
    if (description) event.description = description;
    if (venue) event.venue = venue;
    if (city) event.city = city;

    if (startDate || endDate) {
      const start = startDate ? new Date(startDate) : event.start_date;
      const end = endDate ? new Date(endDate) : event.end_date;

      if (isNaN(start.getTime()) || isNaN(end.getTime())) {
        return next(new ValidationError("Invalid date format"));
      }

      if (start >= end) {
        return next(new ValidationError("Start date must be before end date"));
      }

      event.start_date = start;
      event.end_date = end;
    }

    await eventRepo.save(event);
    res.status(200).json({
      message: "Event updated Sucessfully",
      event: event,
    });
  } catch (err) {
    next(err);
  }
}

export async function cancelEvent(
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) {
  try {
    const eventId = Number(req.params.id);
    const eventRepo = AppDataSource.getRepository(Events);
    const bookingRepo = AppDataSource.getRepository(Bookings);

    const event = await eventRepo
      .createQueryBuilder("event")
      .leftJoinAndSelect("event.organiser", "organiser")
      .where("event.id = :id", { id: eventId })
      .getOne();
    if (!event) {
      return next(new NotFoundError("Event"));
    }
    if (event.organiser.id !== req.user?.id) {
      return next(new ForbiddenError());
    }
    if (event.status === EventStatus.CANCELLED) {
      return next(new ValidationError("Event is already cancelled"));
    }

    const activeBookingCount = await bookingRepo
      .createQueryBuilder("booking")
      .leftJoin("booking.tier", "tier")
      .leftJoin("tier.events", "event")
      .where("event.id = :id", { id: eventId })
      .andWhere("booking.status = :status", { status: BookingStatus.BOOKED })
      .getCount();

    if (activeBookingCount > 0) {
      return next(
        new ValidationError(
          "Cannot cancel event because tickets have already been booked ",
        ),
      );
    }

    event.status = EventStatus.CANCELLED;
    await eventRepo.save(event);

    return res.status(200).json({
      message: "Event cancelled successfully",
      event: event,
    });
  } catch (err) {
    next(err);
  }
}

export async function publishEvent(
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) {
  try {
    const eventId = Number(req.params.id);
    const eventRepo = AppDataSource.getRepository(Events);

    const event = await eventRepo
      .createQueryBuilder("event")
      .leftJoinAndSelect("event.organiser", "organiser")
      .leftJoinAndSelect("event.tiers", "tiers")
      .where("event.id = :id", { id: eventId })
      .getOne();

    if (!event) {
      return next(new NotFoundError("Event"));
    }

    if (event.organiser.id !== req.user?.id) {
      return next(new ForbiddenError());
    }

    if (event.status !== EventStatus.DRAFT) {
      return next(new ValidationError("Only draft events can be published"));
    }

    if (!event.tiers || event.tiers.length === 0) {
      return next(new ValidationError("Cannot publish event without ticket tiers"));
    }

    for (const tier of event.tiers) {
      if (tier.capacity <= 0) {
        throw new ValidationError(
          "All tiers must have capacity greater than 0",
        );
      }
    }

    event.status = EventStatus.PUBLISHED;
    await eventRepo.save(event);

    return res.status(200).json({
      message: "Event published successfully",
      event,
    });
  } 
  catch (err) {
    return next(err);
  }
}
