import { NextFunction, Request, Response } from "express";
import { AppDataSource } from "../data.source";
import { User } from "../entity/User";
import { AuthenticationError, ConflictError, ValidationError } from "../middleware/errorMiddleware";
import { comparePassword, hashPassword } from "../utils/password";
import { signToken } from "../utils/signToken";



export async function register(req: Request, res: Response, next: NextFunction) {
    const { username, password, email } = req.body as { username: string, password: string, email: string }
    if (!username || !password || !email) {
        return next(new ValidationError("Username,email and password field are required"))
    }
    try {
        const userRepo = await AppDataSource.getRepository(User)
        const existingUser = await userRepo.findOne({
            where: [
                { email: email },
                { username: username }
            ]
        })
        if (existingUser) {
            return next(new ConflictError(
                existingUser.email === email ?
                    "email already exists,please use another email" :
                    "username already exists,please use another username"
            ))
        }
        const passwordHash = await hashPassword(password);

        const newUser = userRepo.create({
            username,
            email,
            passwordHash
        });

        await userRepo.save(newUser);

        res.status(201).json({
            message: "User created successfully",
            user: {
                id: newUser.id,
                email: newUser.email,
                username: newUser.username,
            }
        })
    }
    catch (err) {
        next(err)
    }
}

export async function login(req: Request, res: Response, next: NextFunction) {
    const { username, email, password } = req.body as { username: string, email: string, password: string }

    if ((!username && !email) || !password) {
        return next(new ValidationError("Credentials are required"))
    }
    try {
        const userRepo = await AppDataSource.getRepository(User)
        const existingUser = await userRepo.findOne({
                                                where: [
                                                    { email: email },
                                                    { username: username }
                                                ]
                                            });

        if(!existingUser || !(await comparePassword(password,existingUser.passwordHash))){
            return next(new AuthenticationError("Invalid Credentials"))
        }
        
        const token = signToken({sub:existingUser.id,email:existingUser.email})

        // res.cookie("token",token,{
        //     httpOnly:true,
        //     sameSite:'strict',
        //     maxAge: 24 * 60 * 60 * 1000,
        // });

        res.setHeader('Authorization',`Bearer ${token}`)

        res.status(200).json({
            message:"Logged in Successfully",
            token:token,
            user:{
                id:existingUser.id,
                email:existingUser.email,
                username:existingUser.username
            }
        })

    }
    catch (err) {
        next(err)
    }
}

export function logout(req: Request, res: Response){
    // res.clearCookie("token",{
    //     httpOnly:true,
    //     sameSite:"strict",
    // })
    res.setHeader('Authorization','');
    res.status(200).json({message:"Logged out successfully"});
    return;
}