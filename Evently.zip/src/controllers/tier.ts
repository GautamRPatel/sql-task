import { Response, NextFunction } from "express";
import { AuthRequest } from "../types/authRequest";
import {
  ForbiddenError,
  NotFoundError,
  ValidationError,
} from "../middleware/errorMiddleware";
import { AppDataSource } from "../data.source";
import { Events, EventStatus } from "../entity/Events";
import { Tier } from "../entity/Tier";
import { Bookings, BookingStatus } from "../entity/Bookings";

export async function addTier(
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) {
  try {
    const eventId = req.params.id;
    const { name, price, capacity } = req.body as {
      name: string;
      price: number;
      capacity: number;
    };

    const eventRepo = AppDataSource.getRepository(Events);
    const tierRepo = AppDataSource.getRepository(Tier);

    if (!name || !price || !capacity) {
      return next(new ValidationError("Missing Requried fields"));
    }

    if (price <= 0 || capacity <= 0) {
      return next(
        new ValidationError("Price and capacity must be greater than 0"),
      );
    }

    const event = await eventRepo
      .createQueryBuilder("event")
      .leftJoinAndSelect("event.organiser", "organiser")
      .where("event.id = :id", { id: eventId })
      .getOne();

    if (!event) {
      return next(new NotFoundError("Event"));
    }

    if (event.organiser.id !== req.user?.id) {
      return next(new ForbiddenError());
    }

    if (event.status === EventStatus.CANCELLED) {
      return next(new ValidationError("Cannot add tier to cancelled event"));
    }

    const tier = tierRepo.create({
      name,
      price,
      capacity,
      events: { id: event.id } as Events,
    });

    await tierRepo.save(tier);
    res.status(200).json({
      message: "Tier added successfully",
      tier: tier,
    });
  } catch (err) {
    next(err);
  }
}

export async function editTier(
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) {
  try {
    const tierId = Number(req.params.id);
    const { name, price, capacity } = req.body as {
      name: string;
      price: number;
      capacity: number;
    };

    const tierRepo = AppDataSource.getRepository(Tier);
    const bookingRepo = AppDataSource.getRepository(Bookings);

    const tier = await tierRepo
      .createQueryBuilder("tier")
      .leftJoinAndSelect("tier.events", "event")
      .leftJoinAndSelect("event.organiser", "organiser")
      .where("tier.id = :id", { id: tierId })
      .getOne();

    if (!tier) {
      return next(new NotFoundError("Tier"));
    }

    if(tier.events.status===EventStatus.CANCELLED){
        return next(new ValidationError("Event Already Cancelled"));
    }
    
    if (tier.events.organiser.id !== req.user?.id) {
      return next(new ForbiddenError());
    }

    const bookingCount = await bookingRepo
      .createQueryBuilder("booking")
      .where("booking.tierId = :tierId", { tierId })
      .andWhere("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .getCount();

    if (bookingCount > 0) {
      return next(
        new ValidationError("Cannot edit tier after tickets have been sold"),
      );
    }

    if (name) tier.name = name;

    if (price !== undefined) {
      if (price <= 0) {
        return next(new ValidationError("Price must be greater than 0"));
      }
      tier.price = price;
    }

    if (capacity !== undefined) {
      if (capacity <= 0) {
        return next(new ValidationError("Capacity must be greater than 0"));
      }
      tier.capacity = capacity;
    }

    await tierRepo.save(tier);

    return res.status(200).json({
      message: "Tier updated successfully",
      tier,
    });
  } catch (err) {
    next(err);
  }
}

export async function deleteTier(
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) {
  try {
    const tierId = Number(req.params.id);

    const tierRepo = AppDataSource.getRepository(Tier);
    const bookingRepo = AppDataSource.getRepository(Bookings);

    const tier = await tierRepo
      .createQueryBuilder("tier")
      .leftJoinAndSelect("tier.events", "event")
      .leftJoinAndSelect("event.organiser", "organiser")
      .where("tier.id = :id", { id: tierId })
      .getOne();

    if (!tier) {
      return next(new NotFoundError("Tier"));
    }

    if(tier.events.status===EventStatus.CANCELLED){
        return next(new ValidationError("Event Already Cancelled"));
    }
    if (tier.events.organiser.id !== req.user?.id) {
      return next(new ForbiddenError());
    }

    const bookingCount = await bookingRepo
      .createQueryBuilder("booking")
      .where("booking.tierId = :tierId", { tierId })
      .andWhere("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .getCount();

    if (bookingCount > 0) {
      return next(
        new ValidationError("Cannot delete tier after tickets have been sold"),
      );
    }

    await tierRepo.remove(tier);

    return res.status(200).json({
      message: "Tier deleted successfully",
    });
  }
   catch (err) {
    next(err);
  }
}
