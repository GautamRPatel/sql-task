import { Response, NextFunction } from "express";
import { AuthRequest } from "../types/authRequest";
import {
  ForbiddenError,
  NotFoundError,
  ValidationError,
} from "../middleware/errorMiddleware";
import { AppDataSource } from "../data.source";
import { Tier } from "../entity/Tier";
import { EventStatus } from "../entity/Events";
import { Bookings, BookingStatus } from "../entity/Bookings";

export async function bookTicket(
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) {
  try {
    const tierId = Number(req.params.id);
    const { quantity } = req.body as { quantity: number };

    if (!quantity || quantity <= 0) {
      return next(new ValidationError("Quantity must be greater than 0"));
    }

    await AppDataSource.transaction(async (manager) => {
      const tier = await manager
        .getRepository(Tier)
        .createQueryBuilder("tier")
        .leftJoinAndSelect("tier.events", "event")
        .where("tier.id = :id", { id: tierId })
        .getOne();

      if (!tier) {
        throw new NotFoundError("Tier");
      }

      if (tier.events.status !== EventStatus.PUBLISHED) {
        throw new ValidationError("Event is not open for booking");
      }

      if (tier.capacity < quantity) {
        throw new ValidationError("Not enough seats available");
      }

      tier.capacity -= quantity;
      await manager.save(tier);

      const booking = manager.create(Bookings, {
        quantity,
        status: BookingStatus.BOOKED,
        user: { id: req.user?.id },
        tier: { id: tierId },
      });

      await manager.save(booking);
    });

    return res.status(201).json({
      message: "Tickets booked successfully",
    });
  } catch (err) {
    next(err);
  }
}

export async function cancelBooking(
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) {
  try {
    const bookingId = Number(req.params.id);

    await AppDataSource.transaction(async (manager) => {
      const booking = await manager
        .getRepository(Bookings)
        .createQueryBuilder("booking")
        .leftJoinAndSelect("booking.tier", "tier")
        .leftJoinAndSelect("booking.user", "user")
        .where("booking.id = :id", { id: bookingId })
        .getOne();

      if (!booking) {
        throw new NotFoundError("Booking");
      }

      if (booking.user.id !== req.user?.id) {
        throw new ForbiddenError();
      }

      if (booking.status === BookingStatus.CANCELLED) {
        throw new ValidationError("Booking already cancelled");
      }

      const tier = booking.tier;
      tier.capacity += booking.quantity;

      await manager.save(tier);

      booking.status = BookingStatus.CANCELLED;
      await manager.save(booking);
    });

    return res.status(200).json({
      message: "Booking cancelled successfully",
    });
  } catch (err) {
    next(err);
  }
}
