import { NextFunction, Request, Response } from "express";
import { AppDataSource } from "../data.source";
import { Bookings, BookingStatus } from "../entity/Bookings";
import { Tier } from "../entity/Tier";
import { Events, EventStatus } from "../entity/Events";

export async function getJanuaryRevenue(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const result = await AppDataSource.getRepository(Bookings)
      .createQueryBuilder("booking")
      .innerJoin("booking.tier", "tier")
      .innerJoin("tier.events", "event")
      .where("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .andWhere("event.start_date BETWEEN :start AND :end", {
        start: "2025-01-01",
        end: "2025-01-31",
      })
      .select("COALESCE(SUM(tier.price * booking.quantity), 0)", "totalRevenue")
      .getRawOne();

    return res.status(200).json({
      month: "January",
      year: 2025,
      totalRevenue: Number(result.totalRevenue),
    });
  } catch (err) {
    return next(err);
  }
}

export async function getTopCityQ1_2025(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const result = await AppDataSource.getRepository(Bookings)
      .createQueryBuilder("booking")
      .innerJoin("booking.tier", "tier")
      .innerJoin("tier.events", "event")
      .where("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .andWhere("event.start_date BETWEEN :start AND :end", {
        start: "2025-01-01",
        end: "2025-03-31",
      })
      .select("event.city", "city")
      .addSelect("COALESCE(SUM(booking.quantity), 0)", "totalTicketsSold")
      .groupBy("event.city")
      .orderBy("totalTicketsSold", "DESC")
      .limit(1)
      .getRawOne();

    if (!result) {
      return res.status(200).json({
        message: "No ticket sales found for Q1 2025",
        city: null,
        totalTicketsSold: 0,
      });
    }

    return res.status(200).json({
      quarter: "Q1",
      year: 2025,
      city: result.city,
      totalTicketsSold: Number(result.totalTicketsSold),
    });
  } catch (err) {
    return next(err);
  }
}

export async function getTop3BestSellingEvents(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const results = await AppDataSource.getRepository(Bookings)
      .createQueryBuilder("booking")
      .innerJoin("booking.tier", "tier")
      .innerJoin("tier.events", "event")
      .where("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .select("event.id", "eventId")
      .addSelect("event.title", "title")
      .addSelect("event.city", "city")
      .addSelect("COALESCE(SUM(booking.quantity), 0)", "totalTicketsSold")
      .groupBy("event.id")
      .addGroupBy("event.title")
      .addGroupBy("event.city")
      .orderBy("totalTicketsSold", "DESC")
      .limit(3)
      .getRawMany();

    return res.status(200).json({
      topEvents: results.map((event) => ({
        eventId: Number(event.eventId),
        title: event.title,
        city: event.city,
        totalTicketsSold: Number(event.totalTicketsSold),
      })),
    });
  } catch (err) {
    return next(err);
  }
}

export async function getTierBreakdownEvent(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const eventTitle = "Event 12";

    const results = await AppDataSource.getRepository(Bookings)
      .createQueryBuilder("booking")
      .innerJoin("booking.tier", "tier")
      .innerJoin("tier.events", "event")
      .where("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .andWhere("event.title = :title", { title: eventTitle })
      .select("tier.id", "tierId")
      .addSelect("tier.name", "tierName")
      .addSelect("SUM(booking.quantity)", "ticketsSold")
      .addSelect("SUM(tier.price * booking.quantity)", "revenue")
      .groupBy("tier.id")
      .addGroupBy("tier.name")
      .getRawMany();

    if (results.length === 0) {
      return res.status(200).json({
        message: "No bookings found for this event",
        tiers: [],
      });
    }

    // Calculate total revenue
    const totalRevenue = results.reduce(
      (sum, tier) => sum + Number(tier.revenue),
      0,
    );

    // Compute percentage
    const response = results.map((tier) => ({
      tierId: Number(tier.tierId),
      tierName: tier.tierName,
      ticketsSold: Number(tier.ticketsSold),
      revenue: Number(tier.revenue),
      revenuePercentage:
        totalRevenue === 0
          ? 0
          : ((Number(tier.revenue) / totalRevenue) * 100).toFixed(2),
    }));

    return res.status(200).json({
      event: eventTitle,
      totalRevenue,
      tiers: response,
    });
  } catch (err) {
    return next(err);
  }
}

export async function getEventsWithLowSeats(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const results = await AppDataSource.getRepository(Tier)
      .createQueryBuilder("tier")
      .innerJoin("tier.events", "event")
      .select("event.id", "eventId")
      .addSelect("event.title", "title")
      .addSelect("event.city", "city")
      .addSelect("SUM(tier.capacity)", "totalRemainingSeats")
      .groupBy("event.id")
      .addGroupBy("event.title")
      .addGroupBy("event.city")
      .having("SUM(tier.capacity) < :limit", { limit: 10 })
      .orderBy("totalRemainingSeats", "ASC")
      .getRawMany();

    return res.status(200).json({
      events: results.map((event) => ({
        eventId: Number(event.eventId),
        title: event.title,
        city: event.city,
        totalRemainingSeats: Number(event.totalRemainingSeats),
      })),
    });
  } catch (err) {
    return next(err);
  }
}

export async function getAverageTicketPriceByCity(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const results = await AppDataSource.getRepository(Tier)
      .createQueryBuilder("tier")
      .innerJoin("tier.events", "event")
      .where("event.status = :status", {
        status: EventStatus.PUBLISHED,
      })
      .select("event.city", "city")
      .addSelect("ROUND(AVG(tier.price), 2)", "averageTicketPrice")
      .groupBy("event.city")
      .orderBy("averageTicketPrice", "DESC")
      .getRawMany();

    return res.status(200).json({
      results: results.map((row) => ({
        city: row.city,
        averageTicketPrice: Number(row.averageTicketPrice),
      })),
    });
  } catch (err) {
    return next(err);
  }
}

export async function getUniqueAttendeesByOrganiser(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const organiserId = Number(req.params.id);

    const result = await AppDataSource.getRepository(Bookings)
      .createQueryBuilder("booking")
      .innerJoin("booking.tier", "tier")
      .innerJoin("tier.events", "event")
      .where("event.organiserId = :organiserId", { organiserId })
      .andWhere("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .select("COUNT(DISTINCT booking.userId)", "uniqueAttendees")
      .getRawOne();

    return res.status(200).json({
      organiserId,
      uniqueAttendees: Number(result.uniqueAttendees) || 0,
    });
  } catch (err) {
    next(err);
  }
}

export async function getCancelledBookingsAndLostRevenue(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const results = await AppDataSource.getRepository(Bookings)
      .createQueryBuilder("booking")
      .innerJoin("booking.tier", "tier")
      .innerJoin("tier.events", "event")
      .where("booking.status = :status", {
        status: BookingStatus.CANCELLED,
      })
      .select("event.id", "eventId")
      .addSelect("event.title", "title")
      .addSelect("COUNT(booking.id)", "cancelledBookings")
      .addSelect(
        "COALESCE(SUM(tier.price * booking.quantity), 0)",
        "lostRevenue",
      )
      .groupBy("event.id")
      .addGroupBy("event.title")
      .orderBy("lostRevenue", "DESC")
      .getRawMany();

    return res.status(200).json({
      results: results.map((event) => ({
        eventId: Number(event.eventId),
        title: event.title,
        cancelledBookings: Number(event.cancelledBookings),
        lostRevenue: Number(event.lostRevenue),
      })),
    });
  } catch (err) {
    return next(err);
  }
}

export async function getTopRevenueTierType(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const results = await AppDataSource.getRepository(Bookings)
      .createQueryBuilder("booking")
      .innerJoin("booking.tier", "tier")
      .where("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .select("tier.name", "tierName")
      .addSelect(
        "COALESCE(SUM(tier.price * booking.quantity), 0)",
        "totalRevenue",
      )
      .groupBy("tier.name")
      .orderBy("totalRevenue", "DESC")
      .getRawMany();

    return res.status(200).json({
      tierRevenueRanking: results.map((row) => ({
        tierName: row.tierName,
        totalRevenue: Number(row.totalRevenue),
      })),
    });
  } catch (err) {
    return next(err);
  }
}

export async function getPublishedEventsWithZeroBookings(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const results = await AppDataSource.getRepository(Events)
      .createQueryBuilder("event")
      .leftJoin("event.tiers", "tier")
      .leftJoin("tier.bookings", "booking", "booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .where("event.status = :eventStatus", {
        eventStatus: EventStatus.PUBLISHED,
      })
      .groupBy("event.id")
      .having("COUNT(booking.id) = 0")
      .orderBy("event.start_date", "ASC")
      .select([
        "event.id AS eventId",
        "event.title AS title",
        "event.city AS city",
        "event.start_date AS startDate",
      ])
      .getRawMany();

    return res.status(200).json({
      events: results.map((event) => ({
        eventId: Number(event.eventId),
        title: event.title,
        city: event.city,
        startDate: event.startDate,
      })),
    });
  } catch (err) {
    return next(err);
  }
}

export async function getMonthlyRevenueTrend2025(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const results = await AppDataSource.getRepository(Bookings)
      .createQueryBuilder("booking")
      .innerJoin("booking.tier", "tier")
      .innerJoin("tier.events", "event")
      .where("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .andWhere("event.start_date BETWEEN :start AND :end", {
        start: "2025-01-01",
        end: "2025-12-31",
      })
      .select("strftime('%m', event.start_date)", "month")
      .addSelect(
        "COALESCE(SUM(tier.price * booking.quantity), 0)",
        "totalRevenue",
      )
      .groupBy("month")
      .orderBy("month", "ASC")
      .getRawMany();

    return res.status(200).json({
      year: 2025,
      monthlyRevenue: results.map((row) => ({
        month: Number(row.month),
        totalRevenue: Number(row.totalRevenue),
      })),
    });
  } catch (err) {
    return next(err);
  }
}


export async function getTopSpendingUser(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const result = await AppDataSource
      .getRepository(Bookings)
      .createQueryBuilder("booking")
      .innerJoin("booking.tier", "tier")
      .innerJoin("booking.user", "user")
      .where("booking.status = :status", {
        status: BookingStatus.BOOKED,
      })
      .select("user.id", "userId")
      .addSelect("user.username", "username")
      .addSelect(
        "COALESCE(SUM(tier.price * booking.quantity), 0)",
        "totalSpent"
      )
      .groupBy("user.id")
      .addGroupBy("user.username")
      .orderBy("totalSpent", "DESC")
      .limit(1)
      .getRawOne();

    if (!result) {
      return res.status(200).json({
        message: "No bookings found",
        user: null,
      });
    }

    return res.status(200).json({
      userId: Number(result.userId),
      username: result.username,
      totalSpent: Number(result.totalSpent),
    });

  } catch (err) {
    return next(err);
  }
}


export async function getUpcomingEventSeatUtilization(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const today = new Date();
    const next30Days = new Date();
    next30Days.setDate(today.getDate() + 30);

    const results = await AppDataSource
      .getRepository(Events)
      .createQueryBuilder("event")
      .leftJoin("event.tiers", "tier")
      .leftJoin("tier.bookings", "booking")
      .where("event.status = :status", {
        status: EventStatus.PUBLISHED,
      })
      .andWhere("event.start_date BETWEEN :start AND :end", {
        start: today,
        end: next30Days,
      })
      .select("event.id", "eventId")
      .addSelect("event.title", "title")
      .addSelect("event.start_date", "startDate")
      // Sold seats (only BOOKED)
      .addSelect(
        `
        COALESCE(
          SUM(
            CASE 
              WHEN booking.status = '${BookingStatus.BOOKED}' 
              THEN booking.quantity 
              ELSE 0 
            END
          ), 0
        )
        `,
        "soldSeats"
      )
      // Remaining seats (safe — sum tier.capacity once per tier)
      .addSelect("COALESCE(SUM(DISTINCT tier.capacity), 0)", "remainingSeats")
      .groupBy("event.id")
      .addGroupBy("event.title")
      .addGroupBy("event.start_date")
      .orderBy("event.start_date", "ASC")
      .getRawMany();

    const formatted = results.map((event) => {
      const sold = Number(event.soldSeats);
      const remaining = Number(event.remainingSeats);
      const totalCapacity = sold + remaining;

      const percentageSold =
        totalCapacity === 0
          ? 0
          : Number(((sold / totalCapacity) * 100).toFixed(2));

      return {
        eventId: Number(event.eventId),
        title: event.title,
        startDate: event.startDate,
        totalCapacity,
        soldSeats: sold,
        remainingSeats: remaining,
        percentageSold,
      };
    });

    return res.status(200).json({
      upcomingEvents: formatted,
    });

  } catch (err) {
    return next(err);
  }
}