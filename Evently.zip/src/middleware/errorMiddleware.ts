import { Request,Response,NextFunction } from "express";

class AppError extends Error{
    public readonly statusCode:number;
    
    constructor(message:string,code:number){
        super(message);
        Object.setPrototypeOf(this,new.target.prototype);
        this.statusCode = code;
        Error.captureStackTrace(this,this.constructor);
    }
}

export class NotFoundError extends AppError{
    constructor(msg:string,code:number = 404){
        super(msg + " not found",code)
    }
}

export class ValidationError extends AppError{
    constructor(msg:string,code:number = 400){
        super(msg,code);
    }
}
export class AuthenticationError extends AppError{
    constructor(msg:string = "Authentication failed",code:number = 401){
        super(msg,code);
    }
}

export class ForbiddenError extends AppError{
    constructor(msg:string = "You cannot perform this action",code:number = 403){
        super(msg,code);
    }
}

export class ConflictError extends AppError{
    constructor(msg:string = "User already exists",code:number = 409){
        super(msg,code);
    }
}

export function globalErrorHandler(err:Error,req:Request,res:Response,next:NextFunction):void{
    if(err instanceof AppError){
        res.status(err.statusCode).json({error:err.message});
        return;
    }
    // console.log(err);
    res.status(500).json({error:err.message || "Internal Server Error"});
    return;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
}

