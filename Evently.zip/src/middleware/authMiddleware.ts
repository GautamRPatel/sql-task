import { NextFunction, Request, Response } from "express";
import * as jwt from "jsonwebtoken";
import { AppDataSource } from "../data.source";
import { User } from "../entity/User";
import jwtPayload from "../types/jwtPayload";
import { AuthenticationError, NotFoundError } from "./errorMiddleware";
import { AuthRequest } from "../types/authRequest";

export async function verifyToken(req:AuthRequest,res:Response,next:NextFunction){
    const JWT_SECRET = process.env.JWT_SECRET as string;

    // if from cookies
    let token = req.cookies.token;

    // if from headers
    if(!token && (req.headers["authorization"]?.startsWith('Bearer '))){
        token = req.headers["authorization"].slice(7);
    }

    if(!token){
        return next(new AuthenticationError('Missing Token'));
    }

    try{
        const decoded = jwt.verify(token,JWT_SECRET) as jwtPayload;
        const user = await AppDataSource.getRepository(User).createQueryBuilder('user')
                                                            .where("user.id = :id",{id:Number(decoded.sub)})
                                                            .getOne()
        if(!user){
            return next(new NotFoundError("User"));
        }
        req.user = user;
        next();
    }
    catch(err){
        return next(new AuthenticationError("Invalid or Expired token"));
    }
}